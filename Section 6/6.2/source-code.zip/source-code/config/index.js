module.exports = {
  jwtSecret: "dsadsa48415asdas95959"
};
