module.exports = {
  jwtSecret: "dsadsa48415asdas95959",
  redisHOST: "127.0.0.1",
  redisPORT: "6379"
};
