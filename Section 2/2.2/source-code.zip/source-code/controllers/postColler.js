exports.index = (req, res) => {
  res.send({ message: "hi" });
};
