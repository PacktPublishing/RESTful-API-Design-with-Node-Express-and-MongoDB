module.exports = {
  jwtSecret: "dsadsavsf",
  mongoURI: "mongodb://localhost/rest-api-node",
  redisHOST: "127.0.0.1",
  redisPORT: "6379",
  port: 8000
};
